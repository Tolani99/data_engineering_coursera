Set up the database
This reading outlines the steps you need to take to set up a database for the graded assessment.

Little Lemon is a family-owned Mediterranean restaurant. They are developing a Python-based application that needs to connect with the MySQL database so that the booking, menu and orders data can be stored in the respective tables. 

The restaurant owner wants to use the stored data to make data-driven decisions to increase their revenue. Establishing a database is one of their key objectives. 

Follow the given steps to set up the Little Lemon database.

